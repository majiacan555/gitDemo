package Champollion;

public class CEDataNLPText {
	private String ChineseData;
	private String EnglishData;
	public String getChineseData() {
		return ChineseData;
	}
	public void setChineseData(String chineseData) {
		ChineseData = chineseData;
	}
	public String getEnglishData() {
		return EnglishData;
	}
	public void setEnglishData(String englishData) {
		EnglishData = englishData;
	}
}
